<?php
/*
Plugin Name: Sabuj Scroll To Top
Plugin URI: https://sabuj.mokam24.com/demo/plugins/
Author: Mohammad Sabuj Khan
Author URI: https://sabuj.mokam24.com
Version: 1.0.0
Description: The plugin is being used to modify the database
Tags: sabuj, database, sabuj database
Text Domain: scrolltop
Domain Path: /languages
*/


function st_all_files_including(){
    wp_enqueue_style('st-custom-css', plugin_dir_url(__FILE__).'assets/css/custom.css', null, time());
    wp_enqueue_script('st-custom-js', plugin_dir_url(__FILE__).'assets/js/custom.js', array('jquery'), time(), true);
}
add_action('wp_enqueue_scripts', 'st_all_files_including');

function st_text_domain_setup(){
    load_plugin_textdomain( 'scrolltop', false, plugin_dir_path(__FILE__).'/languages' );
}
add_action('plugins_loaded', 'st_text_domain_setup');

function st_adding_something_to_footer(){
    ?>
        <div class="scroll_top">
            <a href="#">go up</a>
        </div>
    <?php
}
add_action('wp_footer', 'st_adding_something_to_footer');


