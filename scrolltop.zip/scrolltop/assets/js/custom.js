;(function($){
    jQuery(document).ready(function(){

        jQuery(window).scroll(function(){
            var distance = jQuery(window).scrollTop();

            if( distance > 100 ){
                jQuery(".scroll_top").fadeIn();
            }else{
                jQuery(".scroll_top").fadeOut();
            }
        });

        jQuery(".scroll_top a").on('click', function(){

            jQuery("html, body").animate({'scrollTop' : 0}, 2000);

            return false;
        });

        

    });

})(jQuery);