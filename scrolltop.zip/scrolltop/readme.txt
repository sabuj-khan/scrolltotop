=== Sabuj Scroll To Top ===
Contributors: shobujkhan
Tags: sabuj, personal, sabuj info, personal info, info, information, employee, employee info, employee,s information
Requires at least: 4.7
Tested up to: 5.4
Stable tag: 4.3
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Sabuj Scroll To Top plugin allows the visitor to easily scroll back to the top of the page.

== Description ==

Sabuj Scroll To Top plugin allows the visitor to easily scroll back to the top of the page, with fully customizable options and image. WPFront Scroll Top plugin has the following features.


== Frequently Asked Questions ==

= Do I need to configure the plugin according to the instruction? =

No, you don't need to configure anything. It's already configured. You just need to active the plugin.

= Is it possible to edit the plugin root file? =

Of course, you can edit the files as you need.

### Features
* Displays a button when user scrolls down the page.
* Scrolls the page back to top with animation.
* Link to an element within the page.
* Link to a different page using URL.
* Create text, image or Font Awesome button.
* Set any image you want.
* Hide on small devices.
* Hide on iframes.
* Pages/Posts filter.
* Auto hide.

== Installation ==
To install the plugin, please go to the github link "https://github.com/sabuj-khan/scrolltotop" and download the main plugin folder. Then you have to upload and install as usual as you do to upload any plugin from your computer. 